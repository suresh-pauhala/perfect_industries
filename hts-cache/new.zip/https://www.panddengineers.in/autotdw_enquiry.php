<html><head>
		<title>403 Forbidden</title>
		</head><body>
		<h1>Forbidden</h1>
		<p>You don't have permission to access <b>/autotdw_enquiry.php</b>
		on this server.</p>
		<p>server1</p>
		</body></html>